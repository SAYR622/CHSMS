﻿using System.Windows.Controls;

namespace Admin_UI.Pages
{
    public partial class DashboardPage : Page
    {
        public DashboardPage()
        {
            InitializeComponent();
        }
    }
}