﻿using Admin_UI.Pages;
using System.Windows;

private void btnDashboard_Click(object sender, RoutedEventArgs e)
{
    MainFrame.Navigate(new DashboardPage());
}

private void btnSites_Click(object sender, RoutedEventArgs e)
{
    MainFrame.Navigate(new HeritageSitesPage());
}

private void btnArtifacts_Click(object sender, RoutedEventArgs e)
{
    MainFrame.Navigate(new ArtifactsPage());
}

private void btnVisitors_Click(object sender, RoutedEventArgs e)
{
    MainFrame.Navigate(new VisitorsPage());
}

private void btnGuides_Click(object sender, RoutedEventArgs e)
{
    MainFrame.Navigate(new TourGuidesPage());
}

private void btnProjects_Click(object sender, RoutedEventArgs e)
{
    MainFrame.Navigate(new ProjectsPage());
}

private void btnEmail_Click(object sender, RoutedEventArgs e)
{
    MainFrame.Navigate(new EmailCenterPage());
}

private void btnReports_Click(object sender, RoutedEventArgs e)
{
    MainFrame.Navigate(new ReportsPage());
}