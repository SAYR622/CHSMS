﻿using System;
using System.Text.RegularExpressions;
using System.Windows;

namespace WpfApp5
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        // Event handler for the professional Create Account process
        private void btnCreateAccount_Click(object sender, RoutedEventArgs e)
        {
            // 1. Extract values and trim unnecessary spaces
            string fullName = txtFullName.Text.Trim();
            string username = txtUsername.Text.Trim();
            string contact = txtContact.Text.Trim();
            string password = txtPassword.Password;
            string gender = rbMale.IsChecked == true ? "Male" : "Female";

            // 2. Comprehensive Professional Validation
            if (string.IsNullOrWhiteSpace(fullName) || string.IsNullOrWhiteSpace(username) ||
                string.IsNullOrWhiteSpace(contact) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("All input fields are mandatory. Please fill them completely.", "Validation Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // Validate Full Name (Should not contain numbers)
            if (Regex.IsMatch(fullName, @"[0-9]"))
            {
                MessageBox.Show("Full Name cannot contain numbers.", "Validation Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // Validate Contact Number (Simple Sri Lankan / International phone format check)
            // Checks if it contains only digits and has a valid length (e.g., 10 digits)
            if (!Regex.IsMatch(contact, @"^[0-9]{10}$"))
            {
                MessageBox.Show("Please enter a valid 10-digit Contact Number.", "Validation Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // Validate Password Strength (Minimum 6 characters for basic professional security)
            if (password.Length < 6)
            {
                MessageBox.Show("Password must be at least 6 characters long for security purposes.", "Security Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // 3. Execution Logic (Database integration point)
            // In production, this data will be securely sent to your DB using Entity Framework or ADO.NET

            string diagnosticSummary = $"Account successfully generated inside system layers:\n\n" +
                                       $"Identified Name: {fullName}\n" +
                                       $"System Username: {username}\n" +
                                       $"Verified Contact: {contact}\n" +
                                       $"Assigned Gender: {gender}";

            MessageBox.Show(diagnosticSummary, "System Success", MessageBoxButton.OK, MessageBoxImage.Information);

            // 4. Reset the view
            ClearFormData();
        }

        // Reset all inputs to default professional state
        private void ClearFormData()
        {
            txtFullName.Clear();
            txtUsername.Clear();
            txtContact.Clear();
            txtPassword.Clear();
            rbMale.IsChecked = true; // Set Male as default fallback
        }
    }
}