﻿using System.Windows;

namespace WpfApp5
{
    // This class handles the application startup
    public partial class App : Application
    {
    }
}