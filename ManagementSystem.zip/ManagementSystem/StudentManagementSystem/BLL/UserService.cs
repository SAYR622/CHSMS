﻿using System;
using CulturalHeritageSiteManagementSystem.DAL;

namespace CulturalHeritageSiteManagementSystem.BLL
{
    public class UserService
    {
        private UserRepository _userRepo;

        public UserService()
        {
            
            _userRepo = new UserRepository();
        }

        [Obsolete]
        public bool Login(string username, string password)
        {
            
            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                throw new Exception("Username and password cannot be empty.");
            }

            if (password.Length < 6)
            {
                throw new Exception("Password must be at least 6 characters long.");
            }

           
            return _userRepo.ValidateUserInDatabase(username, password);
        }
    }
}