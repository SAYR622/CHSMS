﻿using System;
using System.Data.SqlClient;

namespace CulturalHeritageSiteManagementSystem.DAL
{
    public class UserRepository
    {
        
        private string connectionString = "Server=localhost;Database=StudentDB;Integrated Security=True;";

        [Obsolete]
        public bool ValidateUserInDatabase(string username, string password)
        {
            bool isValid = false;

            using (var conn = new System.Data.SqlClient.SqlConnection(connectionString))
            {
                string query = "SELECT COUNT(1) FROM Users WHERE Username = @Username AND Password = @Password";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Username", username);
                    cmd.Parameters.AddWithValue("@Password", password);

                    try
                    {
                        conn.Open();
                        int count = Convert.ToInt32(cmd.ExecuteScalar());
                        if (count == 1) isValid = true;
                    }
                    catch (Exception ex)
                    {
                        
                        throw new Exception("Database error: " + ex.Message);
                    }
                }
            }
            return isValid;
        }
    }
}