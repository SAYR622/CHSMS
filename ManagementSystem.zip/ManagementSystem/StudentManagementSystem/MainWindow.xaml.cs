﻿using System;
using System.Windows;
using CulturalHeritageSiteManagementSystem.BLL;

namespace CulturalHeritageSiteManagementSystem
{
    public partial class MainWindow : Window
    {
        private UserService _userService;

        public MainWindow()
        {
            InitializeComponent();

            
            _userService = new UserService();
        }

        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            try
            {
               
                string username = txtUsername.Text;
                string password = txtPassword.Password;

                
                bool loginSuccess = _userService.Login(username, password);

                
                if (loginSuccess)
                {
                    MessageBox.Show("Login Successful! Welcome to the Cultural Heritage Site System.", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else
                {
                    MessageBox.Show("Invalid username or password.", "Login Failed", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            catch (Exception ex)
            {
                
                MessageBox.Show(ex.Message, "Validation Error", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }
    }
}